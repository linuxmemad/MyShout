@echo off
setlocal
cd /d "%~dp0"

set "CSC64=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
set "CSC32=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if exist "%CSC64%" set "CSC=%CSC64%"
if not defined CSC if exist "%CSC32%" set "CSC=%CSC32%"

if not defined CSC (
  echo Windows C# compiler was not found.
  echo Install .NET Framework 4.x Developer Pack, then run this file again.
  pause
  exit /b 1
)

echo Building UrbanTerrorServerManager.exe...
"%CSC%" /nologo /target:winexe /optimize+ /win32icon:"UrbanTerrorServerManager.ico" /resource:"UrbanTerrorServerManagerLogo.png",UrbanTerrorServerManagerLogo.png /out:"UrbanTerrorServerManager.exe" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll "UrbanTerrorServerManager.cs"

if errorlevel 1 (
  echo.
  echo BUILD FAILED. Send the errors to Sam.
  pause
  exit /b 1
)

echo.
echo BUILD COMPLETE: %CD%\UrbanTerrorServerManager.exe
echo Put the EXE beside the Urban Terror program and run it.
pause
