@echo off
setlocal
cd /d "%~dp0"
title Urban Terror Server Manager Builder
set "LOG=%~dp0BUILD-LOG.txt"

echo Urban Terror Server Manager build started > "%LOG%"
echo Folder: %CD% >> "%LOG%"
echo. >> "%LOG%"

set "CSC64=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
set "CSC32=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if exist "%CSC64%" set "CSC=%CSC64%"
if not defined CSC if exist "%CSC32%" set "CSC=%CSC32%"

if not defined CSC (
  echo ERROR: Windows C# compiler was not found. >> "%LOG%"
  echo.
  echo WINDOWS C# COMPILER NOT FOUND.
  echo Install the .NET Framework 4.8 Developer Pack, then run this file again.
  echo Details were saved to BUILD-LOG.txt.
  pause
  exit /b 1
)

echo Building UrbanTerrorServerManager.exe...
echo Compiler: %CSC% >> "%LOG%"
"%CSC%" /nologo /target:winexe /optimize+ /win32icon:"UrbanTerrorServerManager.ico" /resource:"UrbanTerrorServerManagerLogo.png",UrbanTerrorServerManagerLogo.png /out:"UrbanTerrorServerManager.exe" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll "UrbanTerrorServerManager.cs" >> "%LOG%" 2>&1

if errorlevel 1 (
  echo.
  echo BUILD FAILED. The compiler report is below:
  echo ------------------------------------------------------------
  type "%LOG%"
  echo ------------------------------------------------------------
  echo Send BUILD-LOG.txt to Sam if it still needs repair.
  pause
  exit /b 1
)

echo BUILD COMPLETE: %CD%\UrbanTerrorServerManager.exe >> "%LOG%"
echo.
echo BUILD COMPLETE: %CD%\UrbanTerrorServerManager.exe
echo Starting the manager now...
start "" "%CD%\UrbanTerrorServerManager.exe"
pause
