using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace UrbanTerrorServerManager
{
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    public sealed class BotRow
    {
        public string Profile { get; set; }
        public string DisplayName { get; set; }
        public int Skill { get; set; }
        public string Team { get; set; }
        public int Delay { get; set; }
    }

    public sealed class MainForm : Form
    {
        readonly Color Purple = Color.FromArgb(180, 70, 255);
        readonly Color Back = Color.FromArgb(18, 16, 24);
        readonly Color PanelBack = Color.FromArgb(31, 27, 42);
        readonly Color TextColor = Color.FromArgb(235, 230, 245);

        TextBox txtInstall, txtExe, txtCfg, txtHostname, txtJoin, txtMotd, txtIp,
                txtPort, txtMaxClients, txtMap, txtFrag, txtTime, txtGravity,
                txtKnockback, txtRcon, txtRef, txtAmmo, txtJumpPower, txtCommand;
        ComboBox cmbGameType;
        CheckBox chkStamina, chkNoFall, chkWallJumps, chkAmmo, chkHkJump;
        DataGridView bots;
        Label lblStatus;
        string q3ut4 = "";

        readonly Dictionary<string, string> gameTypes = new Dictionary<string, string>
        {
            {"Free For All", "0"}, {"Last Man Standing", "1"},
            {"Team Deathmatch", "3"}, {"Team Survivor", "4"},
            {"Follow The Leader", "5"}, {"Capture And Hold", "6"},
            {"Capture The Flag", "7"}, {"Bomb Mode", "8"},
            {"Jump", "9"}, {"Freeze Tag", "10"}, {"Gun Game", "11"}
        };

        string IniPath { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UrbanTerrorServerManager.ini"); } }

        public MainForm()
        {
            Text = "Urban Terror 4.3.4 Server Manager — Matrix Minds";
            Width = 1040; Height = 780; MinimumSize = new Size(900, 680);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Back; ForeColor = TextColor;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            var tabs = new TabControl { Dock = DockStyle.Fill };
            tabs.TabPages.Add(BuildServerTab());
            tabs.TabPages.Add(BuildBotsTab());
            tabs.TabPages.Add(BuildLaunchTab());
            Controls.Add(tabs);
            Controls.Add(BuildBottomBar());
            Controls.Add(BuildBrandHeader());

            foreach (var key in gameTypes.Keys) cmbGameType.Items.Add(key);
            cmbGameType.SelectedItem = "Team Deathmatch";
            LoadManagerSettings();
            if (String.IsNullOrWhiteSpace(txtInstall.Text)) AutoLocate();
            else LoadFromInstall(txtInstall.Text);
        }

        Control BuildBrandHeader()
        {
            var header = new Panel { Dock=DockStyle.Top, Height=132, BackColor=Color.FromArgb(12,10,18), Padding=new Padding(14,10,14,10) };
            var logo = new PictureBox { Dock=DockStyle.Left, Width=112, SizeMode=PictureBoxSizeMode.Zoom, BackColor=Color.Transparent };
            logo.Image = LoadBrandImage();

            var words = new Panel { Dock=DockStyle.Fill, BackColor=Color.Transparent, Padding=new Padding(18,8,0,0) };
            var title = new Label { Dock=DockStyle.Top, Height=46, Text="URBAN TERROR SERVER MANAGEMENT", ForeColor=Color.White, Font=new Font("Segoe UI",19,FontStyle.Bold), TextAlign=ContentAlignment.MiddleLeft };
            var sub = new Label { Dock=DockStyle.Top, Height=30, Text="NOLAN SERVER OPS  •  MATRIX MINDS", ForeColor=Purple, Font=new Font("Segoe UI",10,FontStyle.Bold), TextAlign=ContentAlignment.MiddleLeft };
            var love = new Label { Dock=DockStyle.Top, Height=26, Text="Built with love by Matthew and Samantha", ForeColor=Color.FromArgb(220,200,235), Font=new Font("Segoe UI",9,FontStyle.Italic), TextAlign=ContentAlignment.MiddleLeft };
            words.Controls.Add(love); words.Controls.Add(sub); words.Controls.Add(title);
            header.Controls.Add(words); header.Controls.Add(logo);
            return header;
        }

        Image LoadBrandImage()
        {
            try
            {
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("UrbanTerrorServerManagerLogo.png"))
                    if (s != null) using (Image original = Image.FromStream(s)) return new Bitmap(original);
                string external = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"UrbanTerrorServerManagerLogo.png");
                if (File.Exists(external)) using (Image original = Image.FromFile(external)) return new Bitmap(original);
            }
            catch { }
            return null;
        }

        TabPage BuildServerTab()
        {
            var tab = NewTab("Server Control");
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Back };
            var grid = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 4, Padding = new Padding(14) };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            txtInstall = AddText(grid, 0, "Urban Terror folder", "");
            AddButton(grid, 0, 2, "Locate / Browse", delegate { BrowseInstall(); });
            txtExe = AddText(grid, 1, "Server executable", "");
            AddButton(grid, 1, 2, "Browse EXE", delegate { BrowseExe(); });
            txtCfg = AddText(grid, 2, "Active CFG", "server_example.cfg");
            AddButton(grid, 2, 2, "Browse CFG", delegate { BrowseCfg(); });

            txtHostname = AddText(grid, 3, "Server name", "Ohio Death Server");
            txtIp = AddTextAt(grid, 3, 2, "Bind IP", "0.0.0.0");
            txtJoin = AddText(grid, 4, "Join message", "Go ahead, make my day!");
            txtPort = AddTextAt(grid, 4, 2, "Port", "27960");
            txtMotd = AddText(grid, 5, "MOTD", "Urban Terror 4.3.4");
            txtMaxClients = AddTextAt(grid, 5, 2, "Maximum players", "20");

            AddLabel(grid, "Game type", 0, 6);
            cmbGameType = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            StyleControl(cmbGameType); grid.Controls.Add(cmbGameType, 1, 6);
            txtMap = AddTextAt(grid, 6, 2, "Starting map", "ut4_gad_dom_ls");
            txtFrag = AddText(grid, 7, "Frag limit", "250");
            txtTime = AddTextAt(grid, 7, 2, "Time limit", "20");
            txtGravity = AddText(grid, 8, "Gravity", "350");
            txtKnockback = AddTextAt(grid, 8, 2, "Knockback", "1000");
            txtRcon = AddText(grid, 9, "RCON password", ""); txtRcon.UseSystemPasswordChar = true;
            txtRef = AddTextAt(grid, 9, 2, "Referee password", ""); txtRef.UseSystemPasswordChar = true;

            var mods = new GroupBox { Text = "Dad Nolan gameplay modifications", ForeColor = Purple, BackColor = PanelBack, Dock = DockStyle.Top, Height = 145, Padding = new Padding(12) };
            var modGrid = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 3 };
            chkStamina = AddCheck(modGrid, "Infinite stamina", 0, 0, true);
            chkNoFall = AddCheck(modGrid, "No fall damage", 1, 0, true);
            chkWallJumps = AddCheck(modGrid, "Infinite wall jumps", 2, 0, false);
            chkAmmo = AddCheck(modGrid, "Modified ammunition", 0, 1, true);
            txtAmmo = AddCompactText(modGrid, "Ammo amount", "100", 1, 1);
            chkHkJump = AddCheck(modGrid, "HK69 self-launch", 2, 1, true);
            txtJumpPower = AddCompactText(modGrid, "Launch power", "650", 0, 2);
            mods.Controls.Add(modGrid);

            scroll.Controls.Add(mods); scroll.Controls.Add(grid);
            mods.Top = grid.Height + 5;
            tab.Controls.Add(scroll);
            return tab;
        }

        TabPage BuildBotsTab()
        {
            var tab = NewTab("Bot Manager");
            bots = new DataGridView {
                Dock = DockStyle.Fill, BackgroundColor = Back, ForeColor = Color.Black,
                AutoGenerateColumns = false, AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, RowHeadersVisible = false
            };
            bots.Columns.Add(new DataGridViewTextBoxColumn { Name="Profile", HeaderText="Installed bot profile", DataPropertyName="Profile", Width=210 });
            bots.Columns.Add(new DataGridViewTextBoxColumn { Name="DisplayName", HeaderText="Visible name", DataPropertyName="DisplayName", Width=260 });
            var skill = new DataGridViewComboBoxColumn { Name="Skill", HeaderText="Skill", Width=90 };
            skill.Items.AddRange("1","2","3","4","5"); bots.Columns.Add(skill);
            var team = new DataGridViewComboBoxColumn { Name="Team", HeaderText="Team", Width=120 };
            team.Items.AddRange("red","blue","free"); bots.Columns.Add(team);
            bots.Columns.Add(new DataGridViewTextBoxColumn { Name="Delay", HeaderText="Delay ms", Width=100 });

            var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 52, BackColor = PanelBack, Padding = new Padding(8) };
            bar.Controls.Add(MakeButton("Add bot", delegate { AddBot(); }));
            bar.Controls.Add(MakeButton("Remove selected", delegate { RemoveBot(); }));
            bar.Controls.Add(MakeButton("Reload my_bot.txt", delegate { LoadBots(); }));
            bar.Controls.Add(MakeButton("Open botfiles folder", delegate { OpenPath(Path.Combine(q3ut4, "botfiles")); }));
            tab.Controls.Add(bots); tab.Controls.Add(bar);
            return tab;
        }

        TabPage BuildLaunchTab()
        {
            var tab = NewTab("Launch & Tools");
            var panel = new FlowLayoutPanel { Dock=DockStyle.Fill, FlowDirection=FlowDirection.TopDown, WrapContents=false, Padding=new Padding(18), AutoScroll=true, BackColor=Back };
            panel.Controls.Add(MakeHeading("Generated launch command"));
            txtCommand = new TextBox { Width=930, Height=80, Multiline=true, ReadOnly=true, BackColor=PanelBack, ForeColor=TextColor, Font=new Font("Consolas",10) };
            panel.Controls.Add(txtCommand);
            panel.Controls.Add(MakeButton("Refresh command", delegate { RefreshCommand(); }));
            panel.Controls.Add(MakeButton("Save everything", delegate { SaveEverything(); }));
            panel.Controls.Add(MakeButton("SAVE & START SERVER", delegate { if (SaveEverything()) StartServer(); }, 280));
            panel.Controls.Add(MakeButton("Open active CFG", delegate { OpenPath(GetCfgPath()); }));
            panel.Controls.Add(MakeButton("Open q3ut4 folder", delegate { OpenPath(q3ut4); }));
            panel.Controls.Add(MakeButton("Open games.log", delegate { OpenPath(Path.Combine(q3ut4,"games.log")); }));
            tab.Controls.Add(panel);
            return tab;
        }

        Control BuildBottomBar()
        {
            var bar = new Panel { Dock=DockStyle.Bottom, Height=42, BackColor=PanelBack };
            var credit = new Label { Dock=DockStyle.Right, Width=285, Text="Built with love by Matthew and Samantha", ForeColor=Purple, TextAlign=ContentAlignment.MiddleRight, Padding=new Padding(0,0,12,0) };
            lblStatus = new Label { Dock=DockStyle.Fill, Text="Ready", ForeColor=TextColor, TextAlign=ContentAlignment.MiddleLeft, Padding=new Padding(12,0,0,0) };
            bar.Controls.Add(lblStatus); bar.Controls.Add(credit); return bar;
        }

        void AutoLocate()
        {
            var candidates = new List<string>();
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            candidates.Add(Path.Combine(local, "UrbanTerror43"));
            candidates.Add(Path.Combine(local, "UrbanTerror43", "q3ut4"));
            candidates.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "UrbanTerror43"));
            candidates.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "UrbanTerror43"));
            foreach (string c in candidates) if (Directory.Exists(c)) { LoadFromInstall(c); return; }
            Status("Urban Terror was not found automatically. Click Locate / Browse.", true);
        }

        void BrowseInstall()
        {
            using (var f = new FolderBrowserDialog { Description="Select UrbanTerror43 or its q3ut4 folder" })
                if (f.ShowDialog()==DialogResult.OK) LoadFromInstall(f.SelectedPath);
        }

        void LoadFromInstall(string selected)
        {
            string root = selected.Trim();
            if (String.Equals(Path.GetFileName(root), "q3ut4", StringComparison.OrdinalIgnoreCase)) q3ut4 = root;
            else if (Directory.Exists(Path.Combine(root,"q3ut4"))) q3ut4 = Path.Combine(root,"q3ut4");
            else q3ut4 = root;
            txtInstall.Text = Directory.GetParent(q3ut4) != null ? Directory.GetParent(q3ut4).FullName : q3ut4;
            FindExecutable(); FindConfig(); LoadConfig(); LoadBots(); RefreshCommand(); SaveManagerSettings();
        }

        void FindExecutable()
        {
            var roots = new [] { txtInstall.Text, q3ut4 };
            var names = new [] { "Quake3-UrT-Ded.exe", "ioUrTded.exe", "ioUrbanTerror.exe", "Quake3-UrT.exe" };
            foreach (string root in roots)
                foreach (string name in names) {
                    string p=Path.Combine(root,name); if(File.Exists(p)){txtExe.Text=p; return;}
                }
            foreach(string root in roots) if(Directory.Exists(root)) {
                string p=Directory.GetFiles(root,"*.exe").FirstOrDefault(x => Regex.IsMatch(Path.GetFileName(x),"(UrT|UrbanTerror)",RegexOptions.IgnoreCase));
                if(p!=null){txtExe.Text=p; return;}
            }
        }

        void FindConfig()
        {
            if (!Directory.Exists(q3ut4)) return;
            string[] preferred={"example-server.cfg","server_example.cfg","server.cfg","dad_nolan_server.cfg"};
            foreach(string n in preferred){string p=Path.Combine(q3ut4,n);if(File.Exists(p)){txtCfg.Text=n;return;}}
            string first=Directory.GetFiles(q3ut4,"*.cfg").FirstOrDefault();
            if(first!=null)txtCfg.Text=Path.GetFileName(first);
        }

        void BrowseExe()
        {
            using(var f=new OpenFileDialog{Filter="Windows programs (*.exe)|*.exe|All files (*.*)|*.*",InitialDirectory=Directory.Exists(txtInstall.Text)?txtInstall.Text:""})
                if(f.ShowDialog()==DialogResult.OK){txtExe.Text=f.FileName;RefreshCommand();SaveManagerSettings();}
        }

        void BrowseCfg()
        {
            using(var f=new OpenFileDialog{Filter="Urban Terror config (*.cfg)|*.cfg|All files (*.*)|*.*",InitialDirectory=q3ut4})
                if(f.ShowDialog()==DialogResult.OK){q3ut4=Path.GetDirectoryName(f.FileName);txtCfg.Text=Path.GetFileName(f.FileName);LoadConfig();LoadBots();RefreshCommand();}
        }

        string GetCfgPath(){return Path.IsPathRooted(txtCfg.Text)?txtCfg.Text:Path.Combine(q3ut4,txtCfg.Text);}
        string ReadCfg(){string p=GetCfgPath();return File.Exists(p)?File.ReadAllText(p):"";}

        void LoadConfig()
        {
            string s=ReadCfg(); if(s.Length==0)return;
            txtHostname.Text=GetSet(s,"sv_hostname",txtHostname.Text); txtJoin.Text=GetSet(s,"sv_joinmessage",txtJoin.Text);
            txtMotd.Text=GetSet(s,"g_motd",txtMotd.Text); txtIp.Text=GetSet(s,"net_ip",txtIp.Text);
            txtPort.Text=GetSet(s,"net_port",txtPort.Text); txtMaxClients.Text=GetSet(s,"sv_maxclients",txtMaxClients.Text);
            txtMap.Text=GetMap(s,txtMap.Text); txtFrag.Text=GetSet(s,"fraglimit",txtFrag.Text); txtTime.Text=GetSet(s,"timelimit",txtTime.Text);
            txtGravity.Text=GetSet(s,"g_gravity",txtGravity.Text); txtKnockback.Text=GetSet(s,"g_knockback",txtKnockback.Text);
            txtRcon.Text=GetSet(s,"rconpassword",""); txtRef.Text=GetSet(s,"g_refpass","");
            string gt=GetSet(s,"g_gametype","3"); cmbGameType.SelectedItem=gameTypes.FirstOrDefault(x=>x.Value==gt).Key ?? "Team Deathmatch";
            chkStamina.Checked=GetSet(s,"sv_infiniteStamina","1")!="0"; chkNoFall.Checked=GetSet(s,"sv_nofallDamage","1")!="0";
            chkWallJumps.Checked=GetSet(s,"sv_infiniteWallJumps","0")!="0"; chkAmmo.Checked=GetSet(s,"sv_modAmmo","1")!="0";
            txtAmmo.Text=GetSet(s,"sv_modAmmoAmount","100"); chkHkJump.Checked=GetSet(s,"sv_hk69Jump","1")!="0";
            txtJumpPower.Text=GetSet(s,"sv_hk69JumpPower","650"); Status("Loaded "+GetCfgPath(),false);
        }

        void LoadBots()
        {
            if(bots==null)return; bots.Rows.Clear(); string p=Path.Combine(q3ut4,"my_bot.txt"); if(!File.Exists(p))return;
            var rx=new Regex("^\\s*addbot\\s+(\\S+)\\s+([1-5])(?:\\s+(red|blue|free))?(?:\\s+(\\d+))?(?:\\s+\"([^\"]*)\")?",RegexOptions.IgnoreCase);
            foreach(string line in File.ReadAllLines(p)) {
                Match m=rx.Match(line); if(!m.Success)continue;
                bots.Rows.Add(m.Groups[1].Value,m.Groups[5].Success?m.Groups[5].Value:m.Groups[1].Value,m.Groups[2].Value,m.Groups[3].Success?m.Groups[3].Value.ToLower():"free",m.Groups[4].Success?m.Groups[4].Value:"0");
            }
        }

        void AddBot(){bots.Rows.Add("boa","New Bot","3","free","0");}
        void RemoveBot(){foreach(DataGridViewRow r in bots.SelectedRows)if(!r.IsNewRow)bots.Rows.Remove(r);}

        bool SaveEverything()
        {
            try {
                if(!Directory.Exists(q3ut4))throw new Exception("Select the Urban Terror/q3ut4 folder first.");
                SaveConfig(); SaveBots(); SaveManagerSettings(); RefreshCommand(); Status("Saved CFG and bot roster. Backups created.",false); return true;
            } catch(Exception ex){MessageBox.Show(ex.Message,"Could not save",MessageBoxButtons.OK,MessageBoxIcon.Error);Status(ex.Message,true);return false;}
        }

        void SaveConfig()
        {
            string p=GetCfgPath(); string s=File.Exists(p)?File.ReadAllText(p):""; Backup(p);
            s=PutSet(s,"sv_hostname",txtHostname.Text); s=PutSet(s,"sv_joinmessage",txtJoin.Text); s=PutSet(s,"g_motd",txtMotd.Text);
            s=PutSet(s,"net_ip",txtIp.Text); s=PutSet(s,"net_port",txtPort.Text); s=PutSet(s,"sv_maxclients",txtMaxClients.Text);
            s=PutSet(s,"g_gametype",gameTypes.ContainsKey(Convert.ToString(cmbGameType.SelectedItem))?gameTypes[Convert.ToString(cmbGameType.SelectedItem)]:"3");
            s=PutSet(s,"fraglimit",txtFrag.Text); s=PutSet(s,"timelimit",txtTime.Text); s=PutSet(s,"g_gravity",txtGravity.Text); s=PutSet(s,"g_knockback",txtKnockback.Text);
            s=PutSet(s,"rconpassword",txtRcon.Text); s=PutSet(s,"g_refpass",txtRef.Text);
            s=PutSet(s,"sv_infiniteStamina",chkStamina.Checked?"1":"0"); s=PutSet(s,"sv_nofallDamage",chkNoFall.Checked?"1":"0");
            s=PutSet(s,"sv_infiniteWallJumps",chkWallJumps.Checked?"1":"0"); s=PutSet(s,"sv_modAmmo",chkAmmo.Checked?"1":"0");
            s=PutSet(s,"sv_modAmmoAmount",txtAmmo.Text); s=PutSet(s,"sv_hk69Jump",chkHkJump.Checked?"1":"0"); s=PutSet(s,"sv_hk69JumpPower",txtJumpPower.Text);
            s=PutMap(s,txtMap.Text);
            s=Regex.Replace(s,@"(?im)^\s*exec\s+bot_enable\s+1\s*(?://.*)?$","set bot_enable \"1\"");
            s=Regex.Replace(s,@"(?im)^\s*my_bot\.txt\s*$","");
            if(!Regex.IsMatch(s,@"(?im)^\s*exec\s+\"?my_bot\.txt\"?"))s += Environment.NewLine+"exec \"my_bot.txt\""+Environment.NewLine;
            File.WriteAllText(p,s,new UTF8Encoding(false));
        }

        void SaveBots()
        {
            string p=Path.Combine(q3ut4,"my_bot.txt"); Backup(p); var lines=new List<string>{"// Managed by Urban Terror Server Manager","// profile skill team delay \"visible name\""};
            foreach(DataGridViewRow r in bots.Rows) {
                if(r.IsNewRow)continue; string profile=Cell(r,"Profile","boa").Trim(); if(profile.Length==0)continue;
                string name=Cell(r,"DisplayName",profile).Replace("\"",""); string skill=Cell(r,"Skill","3"); string team=Cell(r,"Team","free").ToLower(); string delay=Cell(r,"Delay","0");
                lines.Add(String.Format("addbot {0} {1} {2} {3} \"{4}\"",profile,skill,team,delay,name));
            }
            File.WriteAllLines(p,lines,new UTF8Encoding(false));
        }

        void StartServer()
        {
            if(!File.Exists(txtExe.Text)){MessageBox.Show("Select the server executable first.");return;}
            try { var psi=new ProcessStartInfo(txtExe.Text,BuildArgs()){WorkingDirectory=q3ut4,UseShellExecute=true};Process.Start(psi);Status("Server launched.",false); }
            catch(Exception ex){MessageBox.Show(ex.Message,"Launch failed");Status(ex.Message,true);}
        }

        string BuildArgs(){return String.Format("+set dedicated 2 +set net_ip {0} +set net_port {1} +exec \"{2}\"",txtIp.Text.Trim(),txtPort.Text.Trim(),Path.GetFileName(txtCfg.Text));}
        void RefreshCommand(){if(txtCommand!=null)txtCommand.Text="\""+txtExe.Text+"\" "+BuildArgs();}

        static string GetSet(string s,string key,string fallback){Match m=Regex.Match(s,@"(?im)^\s*seta?\s+"+Regex.Escape(key)+@"\s+\"?([^\"\r\n/]*?)\"?\s*(?://.*)?$");return m.Success?m.Groups[1].Value.Trim():fallback;}
        static string PutSet(string s,string key,string value){value=(value??"").Replace("\"","");string line="set "+key+" \""+value+"\"";string p=@"(?im)^\s*seta?\s+"+Regex.Escape(key)+@"\s+.*$";Regex setting=new Regex(p);return setting.IsMatch(s)?setting.Replace(s,delegate(Match m){return line;},1):s.TrimEnd()+Environment.NewLine+line+Environment.NewLine;}
        static string GetMap(string s,string fallback){Match m=Regex.Match(s,@"(?im)^\s*map\s+(\S+)");return m.Success?m.Groups[1].Value:fallback;}
        static string PutMap(string s,string map){string line="map "+Regex.Replace(map??"",@"[^A-Za-z0-9_\-]","");Regex mapCommand=new Regex(@"(?im)^\s*map\s+\S+.*$");return mapCommand.IsMatch(s)?mapCommand.Replace(s,delegate(Match m){return line;},1):s.TrimEnd()+Environment.NewLine+line+Environment.NewLine;}
        static string Cell(DataGridViewRow r,string name,string fallback){object v=r.Cells[name].Value;return v==null?fallback:Convert.ToString(v);}
        static void Backup(string p){if(File.Exists(p)){string dir=Path.Combine(Path.GetDirectoryName(p),"manager_backups");Directory.CreateDirectory(dir);string name=Path.GetFileName(p)+"."+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".bak";File.Copy(p,Path.Combine(dir,name),true);}}

        void LoadManagerSettings(){if(!File.Exists(IniPath))return;foreach(string line in File.ReadAllLines(IniPath)){int i=line.IndexOf('=');if(i<1)continue;string k=line.Substring(0,i),v=line.Substring(i+1);if(k=="install")txtInstall.Text=v;if(k=="exe")txtExe.Text=v;if(k=="cfg")txtCfg.Text=v;}}
        void SaveManagerSettings(){try{File.WriteAllLines(IniPath,new[]{"install="+txtInstall.Text,"exe="+txtExe.Text,"cfg="+txtCfg.Text});}catch{}}
        void OpenPath(string p){if(String.IsNullOrWhiteSpace(p))return;if(!File.Exists(p)&&!Directory.Exists(p)){MessageBox.Show("Not found:\n"+p);return;}Process.Start(new ProcessStartInfo(p){UseShellExecute=true});}
        void Status(string s,bool error){if(lblStatus!=null){lblStatus.Text=s;lblStatus.ForeColor=error?Color.Salmon:TextColor;}}

        TabPage NewTab(string title){return new TabPage(title){BackColor=Back,ForeColor=TextColor};}
        Label MakeHeading(string text){return new Label{Text=text,ForeColor=Purple,Font=new Font("Segoe UI",14,FontStyle.Bold),AutoSize=true,Margin=new Padding(3,8,3,8)};}
        void StyleControl(Control c){c.BackColor=PanelBack;c.ForeColor=TextColor;c.Font=new Font("Segoe UI",9);}
        void AddLabel(TableLayoutPanel g,string text,int col,int row){var l=new Label{Text=text,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,ForeColor=TextColor,AutoSize=true,Padding=new Padding(0,8,0,4)};g.Controls.Add(l,col,row);}
        TextBox AddText(TableLayoutPanel g,int row,string label,string value){AddLabel(g,label,0,row);var t=new TextBox{Text=value,Dock=DockStyle.Fill};StyleControl(t);g.Controls.Add(t,1,row);return t;}
        TextBox AddTextAt(TableLayoutPanel g,int row,int labelCol,string label,string value){AddLabel(g,label,labelCol,row);var t=new TextBox{Text=value,Dock=DockStyle.Fill};StyleControl(t);g.Controls.Add(t,labelCol+1,row);return t;}
        void AddButton(TableLayoutPanel g,int row,int col,string text,EventHandler click){var b=MakeButton(text,click);b.Dock=DockStyle.Fill;g.Controls.Add(b,col,row);}
        Button MakeButton(string text,EventHandler click,int width=170){var b=new Button{Text=text,Width=width,Height=34,FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(74,35,105),ForeColor=Color.White,Margin=new Padding(5)};b.FlatAppearance.BorderColor=Purple;b.Click+=click;return b;}
        CheckBox AddCheck(TableLayoutPanel g,string text,int col,int row,bool value){var c=new CheckBox{Text=text,Checked=value,ForeColor=TextColor,AutoSize=true,Padding=new Padding(5)};g.Controls.Add(c,col,row);return c;}
        TextBox AddCompactText(TableLayoutPanel g,string label,string value,int col,int row){var p=new FlowLayoutPanel{AutoSize=true};p.Controls.Add(new Label{Text=label,ForeColor=TextColor,AutoSize=true,Padding=new Padding(0,7,3,0)});var t=new TextBox{Text=value,Width=70};StyleControl(t);p.Controls.Add(t);g.Controls.Add(p,col,row);return t;}
    }
}
