@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -Path '.\UrbanTerrorServerManager.cs' -ReferencedAssemblies System.Windows.Forms,System.Drawing,System.Core; [UrbanTerrorServerManager.Program]::Main()"
