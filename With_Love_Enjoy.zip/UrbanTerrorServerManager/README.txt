URBAN TERROR 4.3.4 SERVER MANAGER
=================================

BUILD THE EXE
1. Extract this folder on the Windows computer running Urban Terror.
2. Double-click Build-EXE.bat.
3. It creates UrbanTerrorServerManager.exe in the same folder.
4. Put UrbanTerrorServerManager.exe beside the Urban Terror program, or leave it here and browse to the installation on first launch.

WHAT IT MANAGES
- Finds the UrbanTerror43 / q3ut4 installation.
- Selects the dedicated-server executable and active CFG.
- Edits server name, join message, MOTD, bind IP, port, maximum clients, game type, starting map, limits, gravity and knockback.
- Edits RCON and referee passwords without displaying them openly.
- Controls Dad Nolan mod settings: infinite stamina, no fall damage, wall jumps, ammunition amount and HK69 launch power.
- Adds, removes, renames and configures bots in my_bot.txt.
- Repairs the bot-enable and my_bot.txt exec lines in the selected CFG.
- Makes timestamped backups in q3ut4\manager_backups before every save.
- Shows the exact launch command and can save everything and start the server.
- Uses the custom Nolan Server Ops emblem with genuine transparent background and permanently displays "Built with love by Matthew and Samantha."

BOT NOTE
The Profile field must match a bot profile installed under q3ut4\botfiles. The Visible Name can be anything Dad wants. Skill ranges from 1 to 5.

NETWORK NOTE
0.0.0.0 listens on all local network interfaces. The standard Urban Terror port is 27960. Public Internet hosting may also require Windows Firewall and router port-forwarding rules.

SOURCE TEST
Run-Source.bat is included as a fallback, but the compiled EXE is the intended program.
