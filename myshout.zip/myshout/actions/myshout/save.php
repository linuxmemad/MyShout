<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   My Shout v1.0
 * @author    www.MatrixMinds.org
 * @copyright (C) Matthew Turner
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-2.0.en.html
 */

// Initialize an empty string for $myshout to avoid undefined variable warnings
$myshout_input = input('myshout'); 

// Get the logged-in user
$user = ossn_loggedin_user();

if ($user) {
    // Save the shout to the user's data object, then save the user
    // This is the correct OSSN way to store component-specific user data
    $user->data->MyShout = $myshout_input;
    if ($user->save()) { // Save the entire user object
        ossn_trigger_message(ossn_print('myshout:saved'), 'success');
        redirect(REF); // Redirect back to the previous page
    } else {
        ossn_trigger_message(ossn_print('myshout:save:error'), 'error');
        redirect(REF);
    }
} else {
    ossn_trigger_message(ossn_print('myshout:notlogged_in'), 'error');
    redirect(REF);
}
