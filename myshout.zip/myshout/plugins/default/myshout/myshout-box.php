<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   My Shout v1.0
 * @author    www.MatrixMinds.org
 * @copyright (C) Matthew Turner
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-2.0.en.html
 */

$user = $params['user']; // The user whose profile is being viewed
$myshout = $user->MyShout ?? ''; // Get the shout directly from the user object

// Only display the box if there's content OR if it's the logged-in user's profile (to allow editing)
if (!empty($myshout) || (ossn_isLoggedin() && ossn_loggedin_user()->guid == $user->guid)) {
    $pencil_html = '';
    // Check if it's the current logged-in user's profile
    if (ossn_isLoggedin() && ossn_loggedin_user()->guid == $user->guid) {
        // Prepare an edit pencil icon linking to the account settings page
        $pencil_html = '&nbsp;&nbsp;<a href="' . current_url(true) . '/edit?section=com_myshout"><i class="fa fa-pencil-alt" title="' . ossn_print('com:myshout:edit:label') . '"></i></a>';
    }
    ?>
    <div class="ossn-wall-container">
        <div class="tabs-input">
            <div class="wall-tabs">
                <li class="item">
                    <i class="fa fa-bullhorn"><span><?php echo ossn_print('com:myshout:label') . $pencil_html; ?></span></i>
                </li>
            </div>
        </div>
        <div class="ossn-wall-container-data">
            <?php 
            echo nl2br(htmlspecialchars($myshout)); 
            // Display placeholder if no shout is set and it's the user's own profile
            if (empty($myshout) && ossn_isLoggedin() && ossn_loggedin_user()->guid == $user->guid) {
                echo '<p>' . ossn_print('com:myshout:placeholder') . '</p>';
            }
            ?>
        </div>
    </div>
<?php
}
