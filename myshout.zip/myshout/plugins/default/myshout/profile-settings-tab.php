<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   My Shout v1.0
 * @author    www.MatrixMinds.org
 * @copyright (C) Matthew Turner
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-2.0.en.html
 */

// Use ossn_view_form to ensure proper form handling, including CSRF tokens
echo ossn_view_form('myshout-input',
	array(
		'action' => ossn_site_url('action/myshout/save'),
		'component' => 'myshout', // Component ID
		'id' => 'myshout-form',
		'params' => array(
			'user' => $params['user'] // Pass the user object to the form view
		),
	),
	false
);
