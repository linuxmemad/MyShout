<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   My Shout v1.0
 * @author    www.MatrixMinds.org
 * @copyright (C) Matthew Turner
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-2.0.en.html
 */

$user = $params['user']; // The user object passed from ossn_view_form
$myshout = $user->MyShout ?? ''; // Retrieve current shout from user object property

?>
<div class="ossn-form-group">
    <label><?php echo ossn_print('com:myshout:edit:label'); ?></label>
    <textarea name="myshout" class="form-control"><?php echo htmlspecialchars($myshout); ?></textarea>
</div>
<div class="ossn-form-group">
    <input type="submit" class="btn btn-primary" value="<?php echo ossn_print('save'); ?>" />
</div>
