<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   My Shout v1.0
 * @author    www.MatrixMinds.org
 * @copyright (C) Matthew Turner
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-2.0.en.html
 */

ossn_register_languages('en', array(
    'com:myshout:label' => 'My Shout',
    'com:myshout:edit:label' => 'Edit My Shout',
    'myshout:saved' => 'My Shout has been saved!',
    'myshout:save:error' => 'Could not save My Shout!',
    'myshout:notlogged_in' => 'You must be logged in to save My Shout.',
    'com:myshout:placeholder' => 'Click the pencil icon to add your shout!',
));