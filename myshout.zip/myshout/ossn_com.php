<?php
/**
 * Open Source Social Network
 * @link      https://www.opensource-socialnetwork.org/
 * @package   My Shout v1.0
 * @author    Matthew Turner - www.MatrixMinds.org
 * @copyright (C) Your Name
 * @license   GNU General Public License https://www.gnu.de/documents/gpl-2.0.en.html
 */

define('__MY_SHOUT__', ossn_route()->com . 'myshout/');

function com_myshout_init() {
	// Hook to load content on profile pages
	ossn_add_hook('profile', 'load:content', 'com_myshout_shout_box');
	
	if (ossn_isLoggedin()) {
		ossn_register_action('myshout/save', __MY_SHOUT__ . 'actions/myshout/save.php');

        ossn_add_hook('profile', 'edit:section', 'com_myshout_edit_tab');
        ossn_register_menu_item('profile/edit/tabs', array(
            'name' => 'com_myshout',
            'href' => '?section=com_myshout',
            'text' => ossn_print('com:myshout:label'),
		));
	}
}

function com_myshout_shout_box($hook, $type, $return, $params) {
	// This function will fetch the HTML for the shout box
	// The user object with its 'data' properties (including MyShout) is already in $params['user']
	$extra_html = ossn_plugin_view('myshout/myshout-box', $params);
	
	// Inject the shout box into the profile wall area, similar to ShortBio
	$extended_html = str_replace('<div class="ossn-profile-wall">', '<div class="myshout">' . $extra_html . '</div><div class="ossn-profile-wall">', $return);
	return $extended_html;
}

function com_myshout_edit_tab($hook, $type, $return, $params) {
    if ($params['section'] == 'com_myshout') {
        return ossn_plugin_view('myshout/profile-settings-tab', $params);
    }
}

ossn_register_callback('ossn', 'init', 'com_myshout_init');
